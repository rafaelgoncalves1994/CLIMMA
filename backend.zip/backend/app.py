from flask import Flask
from flask_cors import CORS
from routes.auth import auth_bp
import requests
from weather import weather_bp

app = Flask(__name__)
CORS(app)

app.register_blueprint(auth_bp)
app.register_blueprint(weather_bp)

if __name__ == '__main__':
    app.run(debug=True)